export type Account = {
    name: string
    accountID: number
    userID: number
    iconID: number
    color1: number
    color2: number
    color3: number
}